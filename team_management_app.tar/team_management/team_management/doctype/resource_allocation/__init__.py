# Resource Allocation DocType
